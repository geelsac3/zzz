find / -type d -name thinktank > /tmp/e.txt
