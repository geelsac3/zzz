find / -type f -name infographic_5G-knowledge.jpg > /tmp/111.txt
